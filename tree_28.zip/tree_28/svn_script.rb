require 'active_support'
require 'active_support/core_ext/string'
require 'csv'

file = File.open('output.txt')
#file = File.open('windows_sample_input.txt')
data = file.read

apps = {}

data_by_apps = data.split(/--------/)

data_by_apps.each do |_app|

  next if _app.blank?

  app_name = section_name = nil

  _app.each_line do |line|

    line.squish!
    next if line.blank?
    next if line.start_with? '#' # ignore comments

    if line.start_with? 'File Name:'
      app_name = line.split('/').last.split('-')[0]
      apps[app_name] = {}
      next
    end

    if line =~ /\[(.*)\]/
      section_name = $1
      apps[app_name][section_name] = []
      next
    end

    apps[app_name][section_name] << line

  end

end

# Process Data

apps.each do |app, chunk|
  chunk.each do |section, content|
    data = {}

    content.each do |line|
      line.squish!
      next if line.blank?

      if section == 'groups'
        group, _ids = line.split(/\s=\s/)
        data[group] = _ids.try(:split, ', ')
      else # dirs
        group, permission = line.split(/\s=\s/)
        data[group] = permission
      end
    end

    apps[app][section] = data
  end
end

CSV.open('svn_output.csv', 'wb') do |csv|
  csv << ['APP', 'GROUP', 'ID', 'FOLDER', 'PERMS']

  apps.each do |app, chunk|
    groups = chunk['groups']
    chunk.each do |dir, content|
      next if dir == 'groups'

      content.each do |_group, permission|
        group = _group.gsub('@','')
        group_ids = groups[group]

        next unless group_ids.present?
        group_ids.each do |id|
          csv << [app, group, id, dir, permission]
        end
      end
    end
  end
end
