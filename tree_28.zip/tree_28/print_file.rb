Dir.glob("*.txt") do |file_name|
 puts "#{file_name}"
end