file_dir = 'E:/svn/access_files' #D:/Ruby_active_users/access_files_backup
file = File.open("D:/Ruby_active_users/verified_users.txt", "r")

file.each_line.map do |line| 
  id, file_name, group = line.split

  old_text = File.read("#{file_dir}/#{file_name}-svnaccess.txt")
  new_text = []

  old_text.each_line do |line|
    if line =~ /=/
      line_group, line_ids = line.split("=")

      if line_group.strip == group.strip
        line_ids = line_ids.split(",").reject { |l_id| l_id.strip == id }.join(",")
		  File.open('D:/Ruby_active_users/user_deletion.txt' ,  'a') {|log|
	    log.puts "Removed from file: #{file_name}-svnaccess.txt"
		log.puts "Removed id: #{id}"
		log.puts "Removed from row: #{line_group}"
		log.puts "*" * 50 
	    }
      end

      new_text << "#{line_group}=#{line_ids.chomp("\n")}"
	    else
      new_text << line.chomp("\n")
    end

  end

  File.write("#{file_dir}/#{file_name}-svnaccess.txt", new_text.join("\n"))
end