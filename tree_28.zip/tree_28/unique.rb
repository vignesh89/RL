array = []
@files = Dir.glob("E:/svn/access_files/*.txt")
for values in @files
 #puts "File Name: #{values}"
 file = File.read(values)
file.split(' ').each do |line|
    puts line
    array.push(line.gsub(',', '')) unless array.include? line.gsub(',', '') or !line.include? "nao"
	end
end

puts array