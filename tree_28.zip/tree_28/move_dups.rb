#puts File.readlines("windows_access_files.txt") & File.readlines("linux_svn_access_files.txt")

require 'fileutils'
target = 'E:\\common'
file='common.txt'

lines = File.readlines(file)
lines.each do |line|
  puts line
  FileUtils.mv(line.strip, target)
  end