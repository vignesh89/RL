out_file = "E:/output.txt"
if File.exists?(out_file)
   File.delete(out_file)
end

File.open('E:/output.txt','a') do |final| 				#E:\svn\access_files
  @files = Dir.glob("E:/svn/access_files/*svnaccess.txt")
  for file in @files
    final.puts "File Name: #{file}"
	final.puts
    text = File.open(file, 'r').read.sub(/#$/?\z/, $/)
    text.each_line do |line|
      final << line
	 end
	final.puts "-" * 80
    end
end