lmb = lambda {|bla| "I'm also a proc, and I say #{bla}" }

also_lmb = ->(bla) { "I'm also a proc, and I say #{bla}" }
