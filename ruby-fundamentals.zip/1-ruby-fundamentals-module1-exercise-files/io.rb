print "Enter your name:"
name = gets
puts "Your name is " + name