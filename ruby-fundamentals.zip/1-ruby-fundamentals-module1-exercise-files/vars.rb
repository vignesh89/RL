lander_count = 10

def report
  lander_count = 5
  puts lander_count
end

report

puts lander_count

$log_level = "debug"   # sets logging verbosity