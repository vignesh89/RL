def double(var)
  mult = 2
  var * mult
end

double("abc")

puts "Hello Ruby!"



