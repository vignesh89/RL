puts 'Hello!'

lander_count = 10

def double(val)
  val * 2
end

double("abc")