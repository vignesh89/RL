require_relative "module7/version"
require_relative "module7/spaceship"
require_relative "module7/probe"
