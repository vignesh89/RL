module Module7
  class Probe

  end
end