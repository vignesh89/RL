require "#{__dir__}/lib/module7"
#require_relative "lib/module7"
include Module7

ship = Spaceship.new("Serenity")
ship.launch