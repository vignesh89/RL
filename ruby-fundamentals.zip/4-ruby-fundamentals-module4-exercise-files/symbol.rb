direction = "west"
puts :"turn_#{direction}".to_s   # :turn_west

p "turn_south".to_sym

