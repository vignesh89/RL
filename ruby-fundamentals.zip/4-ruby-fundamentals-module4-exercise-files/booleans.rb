puts true.class

puts true.to_s

puts false.nil?

