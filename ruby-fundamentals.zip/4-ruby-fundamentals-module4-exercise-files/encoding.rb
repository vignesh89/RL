#!/usr/bin/ruby
# encoding: us-ascii
puts "abc".encoding